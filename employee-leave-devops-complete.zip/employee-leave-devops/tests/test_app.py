import os
import tempfile
import pytest

import database
import app as app_module


@pytest.fixture()
def client(monkeypatch):
    db_fd, db_path = tempfile.mkstemp()
    os.close(db_fd)

    monkeypatch.setattr(database, "DATABASE", db_path)

    app_module.app.config.update(
        TESTING=True,
        SECRET_KEY="test-secret"
    )

    database.init_db()

    with app_module.app.test_client() as client:
        yield client

    if os.path.exists(db_path):
        os.unlink(db_path)


def login(client, username, password):
    return client.post(
        "/login",
        data={"username": username, "password": password},
        follow_redirects=True
    )


def test_home_redirects_to_login(client):
    response = client.get("/")
    assert response.status_code == 200
    assert b"Login" in response.data


def test_employee_login(client):
    response = login(client, "employee", "employee123")
    assert response.status_code == 200
    assert b"Employee Dashboard" in response.data


def test_invalid_login(client):
    response = login(client, "employee", "wrong-password")
    assert response.status_code == 200
    assert b"Invalid username or password" in response.data


def test_employee_can_apply_for_leave(client):
    login(client, "employee", "employee123")

    response = client.post(
        "/apply-leave",
        data={
            "leave_type": "Casual Leave",
            "start_date": "2026-10-01",
            "end_date": "2026-10-02",
            "reason": "Personal work"
        },
        follow_redirects=True
    )

    assert response.status_code == 200
    assert b"Leave request submitted successfully" in response.data
    assert b"Pending" in response.data


def test_admin_can_approve_leave(client):
    login(client, "employee", "employee123")

    client.post(
        "/apply-leave",
        data={
            "leave_type": "Sick Leave",
            "start_date": "2026-10-05",
            "end_date": "2026-10-06",
            "reason": "Not feeling well"
        },
        follow_redirects=True
    )

    login(client, "admin", "admin123")

    response = client.post(
        "/update-leave/1/Approved",
        follow_redirects=True
    )

    assert response.status_code == 200
    assert b"Approved" in response.data


def test_health_endpoint(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json["status"] == "healthy"
